# Rulern
Rulern - Easy Learning Classifier Systems in a few lines.
